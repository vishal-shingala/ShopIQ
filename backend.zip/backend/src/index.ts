import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { analyzeReviews } from './lib/ai';
import { analyzeProduct } from './lib/gemini';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/analyze-reviews', async (req, res) => {
  try {
    const { productName, price, reviews } = req.body;

    if (!productName || typeof productName !== 'string' || !productName.trim()) {
      return res.status(400).json({ success: false, error: 'Invalid product name' });
    }
    if (typeof price !== 'number' || price <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid price' });
    }
    if (!reviews || typeof reviews !== 'string' || !reviews.trim()) {
      return res.status(400).json({ success: false, error: 'Invalid reviews' });
    }

    const result = await analyzeReviews(productName, price, reviews);
    return res.json({ success: true, data: result });
  } catch (err) {
    console.error('Analysis error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

function looksLikeProductPage(urlStr: string) {
  try {
    const u = new URL(urlStr);
    const path = u.pathname.toLowerCase();
    if (path.length > 1) return true;
    if (path.includes('/dp/') || path.includes('/product') || path.includes('/p/')) return true;
    if (u.searchParams.has('id')) return true;
    return false;
  } catch (err) {
    return false;
  }
}

app.post('/analyze-product', async (req, res) => {
  try {
    const { productLink, productName, description } = req.body;

    if (!productLink || typeof productLink !== 'string' || !productLink.trim()) {
      return res.status(400).json({ success: false, error: 'Product link is required' });
    }
    if (!/^https?:\/\//i.test(productLink)) {
      return res.status(400).json({ error: 'Invalid product link. Please provide a product page URL.' });
    }
    if (!looksLikeProductPage(productLink)) {
      return res.status(400).json({ error: 'Invalid product link. Please provide a product page URL.' });
    }

    if (!productName || typeof productName !== 'string' || !productName.trim()) {
      return res.status(400).json({ success: false, error: 'Product name is required' });
    }

    const desc = typeof description === 'string' ? description : '';
    if (!desc.trim()) {
      return res.status(400).json({ success: false, error: 'Product description or reviews are required' });
    }

    const aiResult = await analyzeProduct(productLink, productName, desc);
    return res.json(aiResult);
  } catch (err) {
    console.error('Analyze product error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`ShopIQ backend listening on port ${PORT}`);
});

// Simple health endpoint for diagnostics
app.get('/health', (_req, res) => {
  res.json({ status: 'ok' });
});
