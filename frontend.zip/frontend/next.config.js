/** @type {import('next').NextConfig} */
const nextConfig = {
  // App Router is enabled by default
}

module.exports = nextConfig